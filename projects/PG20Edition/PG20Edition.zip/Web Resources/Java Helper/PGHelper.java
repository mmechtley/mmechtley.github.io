/*
* Helper for Power Glove. Reads in serial data via Bluetooth and sends it out
* as UDP packets
*/

import java.io.*;
import java.util.*;
import gnu.io.*;
import java.net.*;

public class PGHelper
{
	// Serial port properties
	static SerialPort serialPort;
	static Enumeration portList;
	static CommPortIdentifier portId;
	static InputStream inputStream;
	static String defaultPort = "/dev/tty.PowerGlove-BT-1";
	
	// UDP socket properties
	static DatagramSocket udpSocket;
	static int sendPort = 23175;
	static InetAddress localhost;
	
	public static void main(String[] args)
	{
		boolean portFound = false;
		
		// check arguments for override of default file or port
		if(args.length > 1)
		{
			defaultPort = args[0];
		}
		
		portList = CommPortIdentifier.getPortIdentifiers();
		
		while(portList.hasMoreElements())
		{
			portId = (CommPortIdentifier) portList.nextElement();
			
			// if we find a port with the proper name, attempt to do shit to it
			if(portId.getName().equals(defaultPort))
			{
				portFound = true;
				
				// open port
				try
				{
					serialPort = (SerialPort) portId.open("PowerGloveHelper", 2000);
				}
				catch(PortInUseException e)
				{
					System.out.println("Port in use by "+e.currentOwner);
					continue;
				}
				
				// set port parameters, particularly baud rate
				try
				{
					serialPort.setSerialPortParams(9600, SerialPort.DATABITS_8, SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
				}
				catch(UnsupportedCommOperationException e)
				{
				}
				
				// open an input stream
				try
				{
					inputStream = serialPort.getInputStream();
					
					// Send "A" to begin receiving data
					OutputStream out = serialPort.getOutputStream();
					out.write('A');
				}
				catch(IOException e)
				{
				}
				
				// create and bind socket for output
				try
				{
					localhost = InetAddress.getLocalHost();
					udpSocket = new DatagramSocket();
				}
				catch(SocketException e)
				{
					System.out.println("Couldn't open socket");
				}
				catch(UnknownHostException e)
				{
					System.out.println("Couldn't find localhost!");
				}
				
				// Start reading
				System.out.println("Listening on port "+defaultPort);
				System.out.println("Broadcasting on UDP port "+sendPort);
				(new Thread(new SerialReader(inputStream, udpSocket))).start();
			}
		}
		
		// If we've checked all ports and none matched, so sad
		if(!portFound)
		{
			System.out.println("port "+defaultPort+" not found.");
		}
	}
	
	// reader thread
	public static class SerialReader implements Runnable
	{
		InputStream in;
		DatagramSocket dgs;
		
		public SerialReader(InputStream in, DatagramSocket dgs)
		{
			this.in = in;
			this.dgs = dgs;
		}
		
		public void run()
		{
			// create a buffer for the input data
			byte[] buffer = new byte[1024];
			int len = -1;
			
			// buffer for outgoing data
			DatagramPacket packet;
			byte[] packetBuffer;
			String bufferStr;
			String output = "";
			int nlIndex = -1;
								
			try
			{
				// read data to buffer
				while((len = this.in.read(buffer)) > -1)
				{
					// Only concat bytes from the buffer that were read this iteration
					bufferStr = new String(buffer, 0, len);
					output = output.concat(bufferStr);
										
					// If we've reached the end of a data packet, send it out
					nlIndex = output.indexOf('\n');
					if(nlIndex >= 0)
					{
						// Convert back to byte array to send packet
						packetBuffer = stringToByteArray(output.substring(0, nlIndex));
						
						// Strip the read substring out
						if(output.length() > nlIndex)
							output = output.substring(nlIndex+1);
						else
							output = "";
						
						//System.out.println(new String(packetBuffer));
						packet = new DatagramPacket(packetBuffer, packetBuffer.length, PGHelper.localhost, PGHelper.sendPort);
						dgs.send(packet);
					}
				}
			}
			catch(IOException e)
			{
			}
		}
		
		/**
		* Reads in a string and converts it to an array of bytes
		*/
		byte[] stringToByteArray(String str)
		{
			int length = str.length();
			byte[] byteArray = new byte[length];
			for(int i=0; i<length; i = i + 1)
			{
				byteArray[i] = (byte)(str.charAt(i) & 0xff);
			}
			return byteArray;
		}
	}
}
