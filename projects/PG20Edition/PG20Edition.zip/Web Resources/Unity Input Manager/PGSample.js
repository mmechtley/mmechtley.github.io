#pragma strict

/*
* A single sample from the PowerGlove -- Three accel axes, four bend values, buttons
*/
class PGSample extends System.Object
{
	// Calibration values
	static var accelZero:int = 512;
	static var accelScale:float = 100.0;
	
	static var bendZeros:float[] = [200.0, 390.0, 420.0, 440.0];
	static var bendMaxes:float[] = [120.0, 120.0, 140.0, 120.0];
		
	// sample values	
	var buttons:PGButton = PGButton.None;
	var fingers:Vector4 = Vector4.zero;
	var accel:Vector3 = Vector3.zero;
	var time:float = 0;
	var raw:PGSampleRaw;
	
	/*
	* Create from string
	*/
	static function Parse(str:String):PGSample
	{
		var newRaw:PGSampleRaw = PGSampleRaw.Parse(str);
		return new PGSample(newRaw);
	}
	
	/*
	* Constructor from raw sample
	*/
	private function PGSample(raw:PGSampleRaw)
	{
		this.raw = raw;
		if(!raw) return;
		this.buttons = raw.buttons;
		this.fingers = new Vector4(MapBend(raw.bend0, 0), 
			MapBend(raw.bend1, 1), MapBend(raw.bend2, 2),
			MapBend(raw.bend3, 3));
		// PG is z-down, y-back, x-left.
		// Re-map to x-right, y-up, z-forward
		this.accel = new Vector3(-MapAccel(raw.accelX), 
			-MapAccel(raw.accelZ), -MapAccel(raw.accelY));
	}
	
	/*
	* Maps a raw accelerometer value to a normalized float (1g = 1)
	*/
	private function MapAccel(val:int):float
	{
		return (val - accelZero)/accelScale;
	}
	
	/*
	* Maps a raw bend value to a normalized float (0..1)
	*/
	private function MapBend(val:int, finger:int):float
	{
		// Bend values are always less than the zero point
		return Mathf.Clamp01((bendZeros[finger] - val)/(bendZeros[finger] - bendMaxes[finger]));
	}
}

/*
* Raw PowerGlove data struct. Integer values directly parsed from string
*/
class PGSampleRaw extends System.Object
{
	var buttons:int = 0;
	var bend0:int = 0;
	var bend1:int = 0;
	var bend2:int = 0;
	var bend3:int = 0;
	var accelX:int = 0;
	var accelY:int = 0;
	var accelZ:int = 0;
	
	static function Parse(str:String):PGSampleRaw
	{
		var samples:String[] = str.Split("\t"[0]);
		// ensure that the sample length was correct, to correct for packet loss
		if(samples.Length == 8)
		{
			var raw:PGSampleRaw = new PGSampleRaw();
			raw.buttons = int.Parse(samples[0]);
			raw.bend0 = int.Parse(samples[1]);
			raw.bend1 = int.Parse(samples[2]);
			raw.bend2 = int.Parse(samples[3]);
			raw.bend3 = int.Parse(samples[4]);
			raw.accelX = int.Parse(samples[5]);
			raw.accelY = int.Parse(samples[6]);
			raw.accelZ = int.Parse(samples[7]);
			
			return raw;
		}
		else
			return null;
	}
}

/*
* PowerGlove buttons
*/
enum PGButton
{
	None = 0x00,
	Up = 0x01,
	Down = 0x02,
	Left = 0x04,
	Right = 0x08,
	B = 0x10,
	A = 0x20,
	Start = 0x40,
	Select = 0x80
}