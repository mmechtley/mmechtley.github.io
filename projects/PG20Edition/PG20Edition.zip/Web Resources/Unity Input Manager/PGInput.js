#pragma strict

/**
* PGInput class reads in UDP data from PGHelper java server. Translates these
* packets into data read samples found in PGSample.js
*
* To use, place this script on a GameObject in your level.
*/

// Oh my, so many imports!
import System.Net.Sockets;
import System.Net;
import System.Threading;
import System.Text;

// The port to listen on
var port:int = 23175;
var showDebug:boolean = false;

// buffer and string of the last packet we read
private var buffer:byte[];
private var lastPacket:String = "";

// References to UDP socket and data read thread
private var client:UdpClient;
private var recThread:Thread;

// Samples from last frame and this frame
private var thisSample:PGSample = PGSample.Parse("");
private var lastSample:PGSample = PGSample.Parse("");

// Singleton logic
static private var ins:PGInput;

function Awake()
{
	ins = this;
	
	InitSocket();
}

function Update()
{
	// Cycle input samples
	if(lastPacket != "")
	{
		lastSample = thisSample;
		thisSample = PGSample.Parse(lastPacket);
		lastPacket = "";
	}
}

function OnDisable()
{
	// kill receive thread if we press stop in the editor
	if(recThread)
		recThread.Abort()
}

/**
* Returns whether the specified button is pressed this frame
*/
static function GetButton(b:PGButton) : boolean
{
	return (b & ins.thisSample.buttons) != 0;
}

/**
* Returns whether the specified button was newly pressed this frame
*/
static function GetButtonDown(b:PGButton) : boolean
{
	return ((b & ins.thisSample.buttons) != 0) && ((b & ins.lastSample.buttons) == 0);
}

/**
* Returns whether the specified button was released this frame
*/
static function GetButtonUp(b:PGButton) : boolean
{
	return ((b & ins.thisSample.buttons) == 0) && ((b & ins.lastSample.buttons) != 0);
}

/**
* Returns the bend value of the specified finger
*/
static function GetFinger(num:int) : float
{
	return (num >=0 && num < 4) ? ins.thisSample.fingers[num] : 0;
}

// Returns the acceleration vector
static function GetAccel() : Vector3
{
	return ins.thisSample.accel;
}

/**
* Initializes the socket connection to the Java server
*/
function InitSocket()
{
	try
	{
		recThread = new Thread(new ThreadStart(ReadData));
		recThread.IsBackground = true;
		recThread.Start();
	}
	catch(e:SocketException)
	{
		Debug.Log("Couldn't open UDP socket to port "+port+e.ToString());
	}
}

/**
* Reads data from the socket connection
*/
function ReadData()
{
	try
	{
		client = new UdpClient(port);
		
		var source:IPEndPoint = new IPEndPoint(IPAddress.Any, 0);
		
		while(enabled)
		{
			buffer = client.Receive(source);
			packet = Encoding.ASCII.GetString(buffer);
			lastPacket = packet;
		}
	}
	catch(e:System.Exception)
	{
		Debug.Log(e.ToString());
	}
}

/**
* Display some debug information
*/
function OnGUI()
{
	if(!showDebug) return;
	
	GUILayout.BeginArea(Rect(0,0,200,100));
	GUILayout.Label(thisSample.accel.ToString());
	GUILayout.Label(thisSample.fingers.ToString());
	GUILayout.Label(System.Enum.Format(PGButton, thisSample.buttons, "F"));
	GUILayout.EndArea();
}