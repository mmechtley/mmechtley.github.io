Power Glove 20th Anniversary Edition Resources
Copyright 2009 Matt Mechtley
http://biphenyl.org

All contents released under a Creative Commons
Attribution Non-Commercial License 3.0
http://creativecommons.org/licenses/by-nc/3.0/us/
This notice may serve as attribution for any 
derivatives or redistributions. 

Arduino -- contains the Power Glove Arduino sketch for the Arduino 
Pro Mini.

Java Helper -- contains a Java program to read in serial data and 
output a text file. Requires the RXTX serial library -- 
http://rxtx.qbang.org/wiki/
Usage: java -jar PGHelper.jar <serial port>
eg: java -jar PGHelper.jar /dev/tty.MySerialPort

Schematic -- contains the circuit schematic

Unity Input Manager -- contains the simple input manager I wrote in Unity3D to calibrate the incoming data and make it easier to interact with. Written in Unity Javascript, almost identical to ActionScript.