# Sequence types (lists, tuples, strings) can be indexed by position like
# in other languages
aList = ['blue','green','red','black','orange','chartreuse']
print(aList[0])

# Negative indexes do what you would want them to
print(aList[-1])

# You can also build subsequences using SLICES, like in fortran, matlab, etc.
# A slice can use colon notation of START:STOP:STEP (Step is optional)
# START is inclusive, STOP is exclusive:
print(aList[1:3])

# You can lazily exclude start or stop, and they will be replaced by 0 and len(list)
print(aList[::2]) # Print every other element


counter = range(6) # range(6) creates the list [0,1,2,3,4,5]
print(counter)
# You can also make slice objects, which can be re-used
mySlice = slice(0,4,2)
print(aList[mySlice])
print(counter[mySlice])

# The del operator (not /that/ del operator) can be used to delete single elements
# (or indeed any variable)
print(aList)
del aList[2]
print(aList)
