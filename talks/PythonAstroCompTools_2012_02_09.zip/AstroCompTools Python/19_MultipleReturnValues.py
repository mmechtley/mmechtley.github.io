# Tuples and tuple unpacking are the preferred way to return multiple values
# Here is a simple example using a Singular Value Decomposition-based
# approximation of a matrix
import numpy as np
from numpy.linalg import svd

def approximateMatrix(someMatrix, rank):
    """
    Returns an approximation of the supplied matrix using its first rank
    eigenvalues, as well as the error in this approximation
    """
    # SVD returns a 3-tuple. We use tuple unpacking to put these in 3
    # different variables
    u, sigma, vT = svd(someMatrix)

    # Shorthand for the sum of the outer products of the first 'rank' columns
    # in u with the first 'rank' rows in vT, multiplied by the first 'rank'
    # eigenvalues
    approx = np.dot(sigma[:rank]*u[:,:rank], vT[:rank,:])

    # Error is the fractional error in the approximation
    error = np.sqrt(np.sum(sigma[rank:]**2) / np.sum(sigma)**2)

    # We return a tuple of approximated matrix and error
    return approx, error

theMatrix = np.arange(64).reshape((8,8))
approxMatrix, fracError = approximateMatrix(theMatrix, 1)

print(theMatrix)
print(approxMatrix)
print(fracError)
