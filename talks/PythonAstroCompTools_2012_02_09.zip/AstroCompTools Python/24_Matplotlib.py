from pylab import *
import readcol, StellarPlots
file = readcol.readcol('simbad_1148_5deg_stars_jhk.txt',asStruct=True,
    skipline=7,fsep='\t',skipafter=1)

# Generate numeric colors based on spectral type
cols = StellarPlots.stellarSpecTypeToFloat(file.spectype)
file.JH = file.MagJ - file.MagH
file.HK = file.MagH - file.MagK

# Color -1 represents unknown spectral type
unknownMask = (cols < 0)
usedMask = (file.identifier == '2MASS J11552259+4937342  ')

starsUnknown = scatter(file.HK[unknownMask], file.JH[unknownMask],
    c='silver', alpha=0.25)
# ~ operator does boolean negation
starsKnow = scatter(file.HK[~unknownMask], file.JH[~unknownMask],
    c=cols[~unknownMask], cmap=StellarPlots.SpecTypeColormap, norm=Normalize(0,9))

qso = scatter([0.61],[0.55],marker='v',c='lightgreen',s=120)

# Show color selection criterion
selection = gca().add_patch(Rectangle((0.61-0.1,0.55-0.1),0.2,0.2,fc='lightgreen', alpha=0.3, zorder=-1))

# Add a color bar
StellarPlots.specTypeColorbar(starsKnow)

# Add a legend
legend(
    (qso,starsKnow, starsUnknown),
    ('J1148+5251','Stars (SIMBAD Spectral Type)','Stars (Unknown Spectral Type)'),
    loc='upper right',scatterpoints=1,fancybox=True,shadow=True,prop={'size':10})

gca().invert_yaxis()
xlabel(r'$(H-K)$')
ylabel(r'$(J-H)$')
# title('QSO J1148+5251 5$^\circ$ Search')
gca().set_aspect('equal',adjustable='datalim')
show()
