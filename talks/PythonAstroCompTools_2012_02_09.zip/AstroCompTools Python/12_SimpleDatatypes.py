# Standard numeric primitives, and strings
aBool = True
anInt = 42
aFloat = 1.0
aComplex = 3+7.5j
aString = 'Cellar door'

# Use the del operator to delete a variable
del anInt
print(anInt)


# LISTS are ordered sets of (potentially) heterogenous data types.
# They have methods to sort, reverse order, insert, etc.
aList1 = [1, 2, 3, 4]
colors = ['pink', 'blue', 'orange']

# List elements can even be other lists, tuples, sets, etc.
# This one is particularly gross, and an abuse of this power
nastyList = [1, 3.0, 'kitty', [5, 6]]


# TUPLES represent /ordered/ data. They cannot be sorted, reversed, etc.
kVector = (0.0, 0.0, 1.0)

# Tuple data can also be heterogenous
exposure = ('F160W', 3500)


# SETS are mathematical sets -- collections with unique elements.
# You can perform set operations like union, intersection, etc.
filters1 = {'F160W', 'F125W', 'F125W', 'F600LP'}
filters2 = set(['F225W', 'F600LP', 'F125W'])

print(filters1.union(filters2)) # Sets (like everything else) are objects.
print(filters1.intersection(filters2)) # They have union() and intersection() methods
print(filters1 - filters2) # Set subtraction, with subtraction operator


# the len() function gets the length of its argument. It works where you want it to.
print(len(aList3))
print(len('kitty')) # Strings have a length too
print(len(filters1)) # Since filters1 is a set, the duplicated F125W is ignored

# The 'in' operator tests for membership
hasPink = 'pink' in colors
print(hasPink)

# It can be used for strings as well
print('cap' in 'capstone')
