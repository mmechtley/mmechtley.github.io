# When you import a module, its members are in its namespace
import math
print math.cos(math.pi*2)

# You can import individual members into the local namespace using the
# 'from X import Y' operator
# Note: cos is a function member, pi is a variable member
from math import cos, pi
print cos(pi*2)

# Sub-Modules can be imported into the local namespace, too
from numpy import random
noise = random.normal(10.0, 3.0, size=(128,128))

# The 'as' operator can be used to rename a long module name in the local namespace
import scipy.ndimage as spIm
smoothNoise = spIm.median_filter(noise, size=3)

# Importing functions from a submodule into the local namespace
from matplotlib.pyplot import imshow, show
imshow(noise, interpolation='nearest')
show()
imshow(smoothNoise, interpolation='nearest')
show()
