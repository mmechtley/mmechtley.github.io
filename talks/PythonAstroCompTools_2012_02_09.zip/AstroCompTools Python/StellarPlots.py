'''
Library functions to help ease making stellar plots
'''

from matplotlib import pyplot as plt
from matplotlib.ticker import FuncFormatter
from matplotlib.colors import LinearSegmentedColormap
from math import floor
from numpy import vectorize

_specTypes = {'None':-1, 'O':0, 'B':1, 'A':2, 'F':3, 'G':4, 'K':5, 'M':6, 'L':7, 'T':8, 'Y':9}
_specColors = ['Purple', 'Blue', 'LightBlue', 'White', 'Yellow', 'Orange', 'Red', 'Maroon', 'Brown', 'Black']
SpecTypeColormap = LinearSegmentedColormap.from_list('Stellar', _specColors)

def specTypeColorbar(*args, **kwargs):
	'''
	Wrapper for pyplot.colorbar that creates a colorbar with ticks for stellar spectral types 
	'''
	cbar = plt.colorbar(*args, ticks=sorted(_specTypes.values())[1:], format=FuncFormatter(tickLabelForSpecType), **kwargs)
	cbar.set_label('Spectral Type')
	cbar.ax.invert_yaxis()
	return cbar

def specStringToFloat(spString):
	'''
	Convert string representation of spectral type to a number ranging from 0 (Y9 dwarf) to 1 (O0)
	Does not account for subtypes I-V.
	@param spString: string representation of spectral type. ex: F2V, A5.4
	@return: floating point representation of spectral type, -1 for unknown/unparseable 
	'''
	spString = spString.lstrip('D') ## Ignore white dwarf specification
	out = _specTypes.get(spString[0], -1) ## Get the integer part from the letter
	try:
		out += 0.1*float(spString[1:].rstrip('IV ')) ## Get fractional part from number after letter
	except ValueError:
		pass
	return out

## Vectorized version of above
stellarSpecTypeToFloat = vectorize(specStringToFloat, otypes=['float'])

def tickLabelForSpecType(tickValue, tickPos):
	return sorted(_specTypes, key=_specTypes.get)[int(floor(tickValue)) + 1] + '0'
