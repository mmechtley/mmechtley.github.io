# DICTIONARIES are a mapping type. Each element is a pair consisting of a
# key and a value. They are commonly used to store record data.
# The keys are often a string, but can be many other types
vitals = {'first':'Patrick',
          'last':'Bateman',
          'age':27,
          'employer':'Pierce & Pierce'}

# You access an element via its key
print(vitals['age'])

# You can add a new pair by assignment
vitals['color'] = 'Bone'

# Keys can be a variable
aKey = 'glasses'
vitals[aKey] = 'Oliver Peoples'

# Non-existant keys will raise an error
print(vitals['eyes']) # raises KeyError since the key doesn't exist

# The get() method takes an optional argument for a default value
print(vitals.get('eyes','Blue'))

# You can get all keys, all values, or tuples of (key, value) using the
# keys() values() and items() methods
print(vitals.keys())
print(vitals.items())
