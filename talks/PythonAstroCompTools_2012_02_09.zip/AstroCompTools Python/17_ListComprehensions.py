# Compact way to generate lists
squares = [x**2 for x in range(10)]
print squares

# Generally, any functions, nested functions, etc. can occur in the generator
names = ['Snake Plissken', 'Patrick Bateman', 'Dirty Harry', 'Debbie Harry']
lasts = [name.split()[1] for name in names]
print(lasts)

# Can also use an 'if' statement for filtering
harrys = [name.split()[0] for name in names if name.split()[1] == 'Harry']
print(harrys)
