from math import sin, pi

def sinc(x):
    """Compute the sinc function:
    sin(x*pi)/(x*pi)"""
    try:
        val = (x*pi)
        return sin(val)/val
    except ZeroDivisionError:
        return 1.0

input = [0.0, 0.25, 0.5, 0.75, 1.0,
         1.25, 1.5, 1.75, 2.0]
output = [sinc(x) for x in input]
