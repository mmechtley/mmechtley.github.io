# Here we have three
players = ['Matt', 'Ben', 'Adam', 'Shawn', 'Steve']
scores = [250, 140, 700, 220, 410]
multipliers = [6, 3, 2, 1, 3]

# Here is an example of using list indexing, as you might write
# a loop in C, etc.
# The i is meaningless except as an index, and makes it more cumbersome to read
for i in range(len(players)):
    line = players[i] + ' ' + str(scores[i]*multipliers[i])
    print(line)

# Here is the preferred, Pythonic way to do the same thing
# zip() creates a list of tuples. The left hand side of 'in' uses
# 'tuple unpacking' to stick the 3 elements of each tuple into 3
# different variables
for player, score, mult in zip(players, scores, multipliers):
    line = player + ' ' + str(score*mult)
    print(line)
